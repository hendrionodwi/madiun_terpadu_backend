---
name: Madiun Terpadu Civic Emerald
version: '1.1'
description: Canonical cross-platform design system for the integrated waste and environmental
  services of Kota Madiun.
colors:
  primary: '#046A58'
  on-primary: '#FFFFFF'
  primary-soft: '#E6F4F1'
  on-primary-soft: '#0F172A'
  accent: '#D97706'
  on-accent: '#0F172A'
  neutral-ink: '#0F172A'
  text-secondary: '#475569'
  text-muted: '#64748B'
  background: '#F8FAFC'
  surface: '#FFFFFF'
  border: '#DDE5E3'
  success: '#15803D'
  success-surface: '#F0FDF4'
  warning: '#D97706'
  warning-surface: '#FFFBEB'
  error: '#DC2626'
  error-surface: '#FEF2F2'
  information: '#0284C7'
  information-surface: '#F0F9FF'
  operational-background: '#0F172A'
  operational-surface: '#1E293B'
  operational-text: '#F8FAFC'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3f4945'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6f7975'
  outline-variant: '#bec9c4'
  surface-tint: '#066b59'
  primary-container: '#046a58'
  on-primary-container: '#95e7d0'
  inverse-primary: '#84d6bf'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#723326'
  on-tertiary: '#ffffff'
  tertiary-container: '#8f4a3b'
  on-tertiary-container: '#ffcbc1'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a0f2db'
  primary-fixed-dim: '#84d6bf'
  on-primary-fixed: '#002019'
  on-primary-fixed-variant: '#005142'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#ffdad3'
  tertiary-fixed-dim: '#ffb4a4'
  on-tertiary-fixed: '#3a0a03'
  on-tertiary-fixed-variant: '#733426'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  code:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
rounded:
  sm: 0.375rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  full: 9999px
  xl: 1.5rem
spacing:
  space-1: 0.25rem
  space-2: 0.5rem
  space-3: 0.75rem
  space-4: 1rem
  space-5: 1.25rem
  space-6: 1.5rem
  space-8: 2rem
  space-10: 2.5rem
  space-12: 3rem
  gutter-mobile: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  gutter: 1.5rem
  margin: 1.5rem
  margin-mobile: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

# Madiun Terpadu Civic Emerald v1.1

Canonical design system for the integrated waste and environmental services of Kota Madiun.
Primary color: #046A58 (Civic Emerald), Primary Soft: #E6F4F1, Accent: #D97706, Neutral Ink: #0F172A, Background: #F8FAFC. Headings in Plus Jakarta Sans, body in Inter, Lucide-style line icons.