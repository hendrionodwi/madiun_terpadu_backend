Create the project design system directly from the uploaded DESIGN.md.
Use the exact canonical tokens defined in the file. Do not replace them with a Stitch preset or infer a different Material color palette.
Name the design system “Madiun Terpadu Civic Emerald v1.1”.
Primary must remain #046A58.
Primary Soft must remain #E6F4F1.
Accent must remain #D97706.
Neutral Ink must remain #0F172A.
Page Background must remain #F8FAFC.
Use Plus Jakarta Sans for headings, Inter for body text, and consistent Lucide-style line icons.
Do not generate application screens yet. First create and activate the project-level design system.